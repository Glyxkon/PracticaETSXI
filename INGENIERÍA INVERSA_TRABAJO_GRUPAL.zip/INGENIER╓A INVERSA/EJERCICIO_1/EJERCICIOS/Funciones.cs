﻿namespace EJERCICIOS
{
    internal class Funciones
    {
        // Función para exportar los pedidos a un archivo de texto
        public static void ExportToFile(CoffeeShop pedidos)
        {
            // Pedir al usuario el nombre del archivo a exportar
            Console.Write("Introduzca el nombre del archivo a exportar: ");
            string ini = "../../../Facturas/";
            string fileName = Console.ReadLine().Trim();

            //Juntamos 
            fileName = ini + fileName;

            // Añadir extensión .txt si no la tiene
            if (!fileName.EndsWith(".txt"))
            {
                fileName += ".txt";
            }

            // Pedir confirmación 
            Console.WriteLine($"Se va a crear el archivo  en la ruta actual {fileName}.");
            Console.Write("¿Desea continuar? (s/n): ");
            string respuesta = Console.ReadLine();

            if (respuesta.ToLower() == "s")
            {
                try
                {
                    // Crear el archivo
                    using (StreamWriter file = new StreamWriter(fileName))
                    {
                        // Escribir los pedidos pagados en el archivo
                        foreach (Orders order in pedidos.GetPaidOrders())
                        {
                            file.WriteLine($"Fecha: {order.GetDate().GetDia()}/{order.GetDate().GetMes()}/{order.GetDate().GetAnio()}/ {order.GetDate().GetHora()}h - {order.GetTotal()}€");

                            foreach (Product product in order.GetProducts())
                            {
                                file.WriteLine($"{product.GetName()} - {product.GetPrice()}€");
                            }
                            file.WriteLine("-----------------------------------------\n");
                        }
                    }

                    Console.WriteLine($"Los pedidos han sido exportados al archivo {fileName}.");
                    //Cerrar el fichero 
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Error al crear el archivo: {e.Message}");
                }
            }
            else
            {
                Console.WriteLine("La operación ha sido cancelada.");
            }
            Console.WriteLine("");
            Console.Write("Pulse enter.");
            Console.ReadKey();

        }
        //Mostrar el total de la caja realizada
        public static void ShowTotal(CoffeeShop pedidos)
        {
            decimal totalPagado = 0;
            int index = 0;

            foreach (Orders order in pedidos.GetPaidOrders())
            {
                totalPagado += order.GetTotal();
                index++;
            }

            Console.WriteLine("----------------");
            Console.WriteLine("Pedidos pagados: {0}", index);
            Console.WriteLine("----------------");
            Console.WriteLine($"Total pagado: {totalPagado}€");
            Console.WriteLine("");
            Console.Write("Pulse enter.");
            Console.ReadKey();
        }

        //Funcion para pagar un pedido
        public static CoffeeShop PayOrder(CoffeeShop pedidos)
        {
            //Variables
            Orders currentOrder = pedidos.GetUnpaidOrders()[0];
            decimal totalAmount = currentOrder.GetTotal();

            Console.WriteLine($"Su pedido es: ");

            foreach (Product product in currentOrder.GetProducts())
            {
                Console.WriteLine($"{product.GetName()} - {product.GetPrice()}€");
            }

            Console.WriteLine($"Total a pagar: {totalAmount}€");

            decimal cantidadPagada = 0;
            bool cantidadValida = false;
            while (!cantidadValida)
            {
                Console.Write("Introduzca su efectivo: ");
                while (!decimal.TryParse(Console.ReadLine(), out cantidadPagada))
                {
                    Console.Write("Introduzca una cantidad decimal válida: ");
                }

                if (cantidadPagada < totalAmount)
                {
                    Console.Write("La cantidad introducida es menor que el total. ¿Desea volver a intentarlo? (s/n): ");
                    string respuesta = Console.ReadLine();
                    if (respuesta.ToLower() == "n")
                    {
                        return pedidos;
                    }
                }
                else
                {
                    cantidadValida = true;
                }
            }

            decimal cambio = cantidadPagada - totalAmount;
            Console.WriteLine($"Gracias, su cambio es: {cambio}€");

            // Mover el pedido de la lista de pedidos inpagados a la de pagados
            pedidos.RemoveOrders(pedidos);
            pedidos.AddPaidOrder(pedidos, currentOrder);
            Console.WriteLine("");
            Console.Write("Pulse enter.");
            Console.ReadKey();
            return pedidos;
        }


        //Funcion para realizar un pedido
        public static CoffeeShop MakeOrder(List<Product> productList, CoffeeShop pedidos)
        {

            Orders newOrder = Funciones.SelectProducts(productList);
            pedidos.AddUnpaidOrder(pedidos, newOrder);
            Console.WriteLine("");
            Console.WriteLine($"Se ha agregado un nuevo pedido a la cola - Total: {newOrder.GetTotal()}€");
            Console.WriteLine("");
            Console.Write("Pulse enter.");
            Console.ReadKey();
            return pedidos;
        }


        // Función para seleccionar productos de la lista y obtener el total del pedido
        public static Orders SelectProducts(List<Product> productList)
        {
            //Variables
            int index = 1;
            string input;
            List<Product> products = new List<Product>();
            decimal total = 0;

            Console.WriteLine("Seleccione los productos que desea añadir a la orden:");
            Console.WriteLine("(Escriba FIN para finalizar)");
            Console.WriteLine();

            // Mostrar la lista de productos y dejar que el usuario seleccione los que quiera
            do
            {
                Console.Clear();
                Console.WriteLine("Lista de productos:");
                foreach (Product product in productList)
                {
                    Console.WriteLine($"{index}. {product.GetName()} - {product.GetPrice()}€");
                    index++;
                }

                input = Console.ReadLine();
                input = input.ToUpper();

                if (input != "FIN")
                {
                    // Añadir el producto seleccionado a la lista de productos de la orden
                    bool isNumber = int.TryParse(input, out int selectedProductIndex);

                    if (isNumber && selectedProductIndex >= 1 && selectedProductIndex <= productList.Count)
                    {
                        Product selectedProduct = productList[selectedProductIndex - 1];
                        products.Add(selectedProduct);
                        total += selectedProduct.GetPrice();
                    }
                    else
                    {
                        Console.WriteLine("Entrada inválida. Por favor, introduzca un número válido o 'FIN' para finalizar el pedido.");
                        Console.Write("Pulse enter.");
                        Console.ReadKey();
                    }
                }

                index = 1;

            } while (input != "FIN");


            Console.Clear();
            Console.WriteLine("Se han seleccionado los siguientes productos:");
            foreach (Product product in products)
            {
                Console.WriteLine($"{product.GetName()} - {product.GetPrice()}€");
            }

            //Crear objeto de tipo Order y añadir la lista de productos y el total de la orden
            Orders order = new Orders();
            order.SetProducts(products);
            order.SetTotal(total);
            order.SetDate(Date.GetDateNow());

            return order;
        }

        //Funcion para finalizar el programa
        public static bool Finalizar()
        {
            return false;
        }

        //Para finalizar el programa 
        public static void Bye()
        {
            Console.WriteLine("Muchas gracias por su visita. Esperemos que vuelva pronto.");
            Console.WriteLine("");
            Console.WriteLine("Pulse enter.");
            Console.ReadKey();
        }

    }
}
