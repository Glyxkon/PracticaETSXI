﻿namespace EJERCICIOS
{
    internal class Orders : Date
    {
        // Atributos
        private List<Product> products;
        private Date date;
        private decimal total;

        // Constructores
        public Orders() { }
        public Orders(List<Product> products, Date date, decimal price)
        {
            this.products = products;
            this.date = date;
            this.total = price;
        }

        internal Product Product
        {
            get => default;
            set
            {
            }
        }

        // Setters y Getters
        public void SetProducts(List<Product> products)
        {
            this.products = products;
        }

        public List<Product> GetProducts()
        {
            return products;
        }

        public void SetDate(Date date)
        {
            this.date = date;
        }

        public Date GetDate()
        {
            return date;
        }

        public void SetTotal(decimal price)
        {
            this.total = price;
        }

        public decimal GetTotal()
        {
            return total;
        }

    }
}
