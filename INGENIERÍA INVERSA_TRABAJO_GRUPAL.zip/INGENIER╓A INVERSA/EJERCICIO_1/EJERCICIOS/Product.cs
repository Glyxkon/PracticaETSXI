﻿class Product
{
    //Ruta para cargar los productos
    public const string filePath = "../../../ListaProductos/ProductosCafeteria.txt";

    //Atributos
    private string name;
    private decimal price;

    // Constructor 
    public Product() { }
    public Product(string name, decimal price)
    {
        this.name = name;
        this.price = price;
    }

    // Métodos getters y setters para los atributos
    public string GetName()
    {
        return this.name;
    }

    public void SetName(string nombre)
    {
        this.name = nombre;
    }

    public decimal GetPrice()
    {
        return this.price;
    }

    public void SetPrice(decimal price)
    {
        this.price = price;
    }


    // Método para obtener los productos con su precio de un archivo .txt
    public List<Product> GetProductsFromFile()
    {
        List<Product> productList = new List<Product>();
        string[] lines = File.ReadAllLines(filePath);

        foreach (string line in lines)
        {
            string[] values = line.Split(';');
            string name = values[0].Trim();
            decimal price = decimal.Parse(values[1].Trim());
            Product product = new Product(name, price);
            productList.Add(product);
        }

        return productList;
    }
}
