﻿namespace RECUPERACION_ENDIKA
{
    internal class Agenda : Funciones, MENU
    {
        //ATRIBUTOS
        private List<Contacto> AgendaPropia;

        //CONSTRUCTORES
        public Agenda()
        {
            AgendaPropia = new List<Contacto>();
        }
        public Agenda(List<Contacto> agendaPropia)
        {
            AgendaPropia = agendaPropia;
        }

        internal Contacto Contacto
        {
            get => default;
            set
            {
            }
        }

        //GETTERS
        public List<Contacto> GetAgenda() { return this.AgendaPropia; }

        //SETTERS
        public void SetAgenda(List<Contacto> agenda)
        {
            this.AgendaPropia = agenda;
        }

        //METODOS
        //1.- Añadir contacto
        public void AñadirContacto(Contacto contacto)
        {
            AgendaPropia.Add(contacto);
        }

    }
}
