﻿namespace RECUPERACION_ENDIKA
{
    internal class Contacto
    {
        //ATRIBUTOS
        private string Nombre;
        private string Grupo;
        private string tlf;
        private bool Lugar;

        //CONSTRUCTORES
        public Contacto() { }
        public Contacto(string Nombre, string Grupo, string tlf)
        {
            this.Nombre = Nombre;
            this.Grupo = Grupo;
            this.tlf = tlf;
            this.Lugar = true; //Si el valor esta true estara en la SIM en caso contrario no lo estara
        }

        //GETTERS
        public string GetNombre() { return this.Nombre; }
        public string GetGrupo() { return this.Grupo; }
        public string GetTlf() { return this.tlf; }
        public bool GetLugar() { return this.Lugar; }

        //SETTERS
        public void SetNombre(string Nombre) { this.Nombre = Nombre; }
        public void SetGrupo(string Grupo) { this.Grupo = Grupo; }
        public void SetTlf(string tlf) { this.tlf = tlf; }

        public void SetLugar(bool lugar) { this.Lugar = lugar; }


        //METODOS
        //1.- Mover contacto a Memoria
        public void MoverMemoria()
        {
            this.Lugar = false;
        }
        //2.- Mover contacto a Sim
        public void MoverSim()
        {
            this.Lugar = true;
        }
        //3.- Modificar grupo de contacto
        public bool ModificarGrupo(string cambioGrupo)
        {
            if (this.Lugar != true)
            {
                this.Grupo = cambioGrupo;
            }
            return this.Lugar;
        }
        //4.- Modificar teléfono de contacto
        public bool ModificarTlf(string tlfNuevo)
        {
            if (this.Lugar != true)
            {
                this.tlf = tlfNuevo;
            }
            return this.Lugar;
        }


    }
}
