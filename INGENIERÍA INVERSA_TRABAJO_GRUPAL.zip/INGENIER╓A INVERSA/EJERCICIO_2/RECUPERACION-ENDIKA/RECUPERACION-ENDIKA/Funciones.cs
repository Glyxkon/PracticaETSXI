﻿namespace RECUPERACION_ENDIKA
{
    internal class Funciones
    {
        //PARTE COMPLEMENTARIA A LOS METODOS DE CONTACTO.CS
        public static Contacto ObtenerContacto(Agenda agenda)
        {
            Contacto contactoNuevo = new Contacto();
            Console.WriteLine("Introduzca un nombre:");
            string nombre = Console.ReadLine();
            if(ComprobarNombre(agenda, nombre))
            {
                foreach(var contacto in agenda.GetAgenda())
                {
                    if(contacto.GetNombre() == nombre)
                    {
                        contactoNuevo = contacto;
                    }
                }
            }
            else
            {
                Console.WriteLine("El nombre no existe.");
            }
            return contactoNuevo;
        }


        //1.- Parte complementaria a metodo de agenda para añadir contacto
        public static Contacto SolicitarDatos(Agenda agenda)
        {
            //Pedimos el nombre
            string nombre = ObtenerNmbre(agenda);

            //Pedimo el telefono
            string tlf = ObtenerTelefono(agenda);

            //Pedimos el grupo
            Console.WriteLine("Introduce el grupo del contacto:");
            string grupo = Console.ReadLine();

            Contacto contacto = new Contacto(nombre, grupo, tlf);
            Console.WriteLine("El contacto fue creado con exito");
            Console.ReadKey();
            return contacto;
        }
        public static string ObtenerTelefono(Agenda agenda)
        {
            string numeroTelefono;
            bool numeroValido = false;
            do
            {
                Console.WriteLine("Ingrese un numero de teléfono: ");
                numeroTelefono = Console.ReadLine();
                if (numeroTelefono.Length == 9 && (numeroTelefono.StartsWith("9") || numeroTelefono.StartsWith("8") || numeroTelefono.StartsWith("6")))
                {
                    numeroValido = true;
                }
            } while (!numeroValido);

            return numeroTelefono;
        }
        public static string ObtenerNmbre(Agenda agenda)
        {
            string nombre;
            bool validation = false;
            do
            {
                Console.WriteLine("Introduzca el nombre del usuario: ");
                nombre = Console.ReadLine().Trim();
                if(ComprobarNombre(agenda, nombre) || agenda.GetAgenda().Count == 0 || nombre.Length >= 1)
                {
                    validation = true;
                }

            } while (!validation);

            return nombre;
        }
        public static bool ComprobarNombre(Agenda agenda, string nombre)
        {
            bool comprobante = false;
            foreach (var contacto in agenda.GetAgenda())
            {
                if (contacto.GetNombre() == nombre)
                {
                    comprobante = true;
                }
            }
            return comprobante;
        }

        //6.- Mostrar los contactos que estan en SIM
        public static int MostrarSim(Agenda agenda)
        {
            int cont = 0;
            foreach (var contacto in agenda.GetAgenda())
            {
                if (contacto.GetLugar())
                {
                    Console.WriteLine($"Nombre: {contacto.GetNombre()}\t\t Grupo: {contacto.GetGrupo()}\t\t Teléfono: {contacto.GetTlf()}");
                    cont++;
                }
            }
            Console.WriteLine("Pulse enter");
            Console.ReadKey();
            return cont;
        }
        //7.- Mostrar los contactos que estan en Memoria
        public static int MostrarMemoria(Agenda agenda)
        {
            int cont = 0;
            foreach (var contacto in agenda.GetAgenda())
            {
                if (!contacto.GetLugar())
                {
                    Console.WriteLine($"Nombre: {contacto.GetNombre()}\t\t Grupo: {contacto.GetGrupo()}\t\t Teléfono: {contacto.GetTlf()}");
                    cont++;
                }
            }
            Console.WriteLine("Pulse enter");
            Console.ReadKey();
            return cont;
        }

        //Funciones para finalizar
        public static bool Finalizar()
        {
            return false;
        }
        //Funcion para finalizar el programa
        public static void Bye()
        {
            Console.WriteLine("AGENDA CERRADA CORRECTAMENTE!!");
            Console.WriteLine("");
            Console.WriteLine("Pulse enter.");
            Console.ReadKey();
        }
    }
}
