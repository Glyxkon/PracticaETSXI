﻿namespace EJERCICIOS
{
    internal class CoffeeShop : Funciones
    {
        //Atributos
        private List<Orders> unpaidOrders;
        private List<Orders> paidOrders;

        //Constructores
        public CoffeeShop()
        {
            unpaidOrders = new List<Orders>();
            paidOrders = new List<Orders>();
        }

        internal Orders Orders
        {
            get => default;
            set
            {
            }
        }

        public MENU MENU
        {
            get => default;
            set
            {
            }
        }

        // Setters y Getters
        public void SetUnpaidOrders(List<Orders> unpaidOrders)
        {
            this.unpaidOrders = unpaidOrders;
        }

        public List<Orders> GetUnpaidOrders()
        {
            return unpaidOrders;
        }

        public void SetPaidOrders(List<Orders> paidOrders)
        {
            this.paidOrders = paidOrders;
        }

        public List<Orders> GetPaidOrders()
        {
            return paidOrders;
        }


        //Metodos 
        //Añadir pedidos pagados o no 
        public void AddUnpaidOrder(CoffeeShop pedidos, Orders order)
        {
            List<Orders> orders = pedidos.GetUnpaidOrders();
            orders.Add(order);
            pedidos.SetUnpaidOrders(orders);
        }

        public void AddPaidOrder(CoffeeShop pedidos, Orders order)
        {
            List<Orders> orders = pedidos.GetPaidOrders();
            orders.Add(order);
            pedidos.SetPaidOrders(orders);
        }

        //Quitar pedido 
        public void RemoveOrders(CoffeeShop pedidos)
        {
            List<Orders> orders = pedidos.GetUnpaidOrders();
            orders.RemoveAt(0);
            pedidos.SetUnpaidOrders(orders);
        }
    }
}
