﻿namespace EJERCICIOS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //variables
            int option = 0;
            bool noerror = true;
            CoffeeShop pedidos = new CoffeeShop();

            //Precargamos los productos 
            Product product = new Product();
            List<Product> lista = product.GetProductsFromFile();

            do
            {
                Menu.ShowMenu();
                option = Menu.ReadOption();
                Console.Write("\n");
                switch (option)
                {
                    //Realizar pedido nuevo
                    case 1:
                        if (pedidos.GetUnpaidOrders().Count >= 5)
                        {
                            Console.WriteLine("Lo sentimos, no se puede realizar el pedido en este momento. Hay demasiado trabajo en la cola.");
                            //Paramos para poder ver el console writeline
                            Console.ReadKey();
                        }
                        else
                        {
                            pedidos = Funciones.MakeOrder(lista, pedidos);
                        }
                        break;

                    //Pagar el pedido
                    case 2:
                        if (pedidos.GetUnpaidOrders().Count() == 0)
                        {
                            Console.WriteLine("No hay pedidos pendientes de pago. Pongamonos a trabajar");
                            //Paramos para poder ver el console writeline
                            Console.ReadKey();
                        }
                        else
                        {
                            pedidos = Funciones.PayOrder(pedidos);
                        }
                        break;

                    //Ver total de la caja
                    case 3:
                        if (pedidos.GetPaidOrders().Count() == 0)
                        {
                            Console.WriteLine("No hay pedidos pagados todavia.");
                            //Paramos para poder ver el console writeline
                            Console.ReadKey();
                        }
                        else
                        {
                            Funciones.ShowTotal(pedidos); ;
                        }
                        break;

                    //Exportar datos 
                    case 4:
                        if (pedidos.GetPaidOrders().Count() == 0)
                        {
                            Console.WriteLine("No hay informacion disponible todavia.");
                            //Paramos para poder ver el console writeline
                            Console.ReadKey();
                        }
                        else
                        {
                            Funciones.ExportToFile(pedidos);
                        }
                        break;

                    //Finalizar
                    case 5: noerror = Funciones.Finalizar(); break;
                }


            } while (noerror);

            //Finalizamos
            Funciones.Bye();
        }
    }
}