﻿namespace EJERCICIOS
{
    internal class Menu
    {
        public static void ShowMenu()
        {
            Console.Clear();
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("-          Bienvenido Cliente                -");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("-  Pulsar una de las  siguientes opciones    -");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("- 1. Realizar Pedido Nuevo.                  -");
            Console.WriteLine("- 2. Pagar Pedido.                           -");
            Console.WriteLine("- 3. Ver total de caja.                      -");
            Console.WriteLine("- 4. Exportar datos de los pedidos hechos.   -");
            Console.WriteLine("- 5. Exit Coffee Shop                        -");
            Console.WriteLine("----------------------------------------------");
        }

        public static int ReadOption()
        {
            ConsoleKeyInfo tecla;
            int valor;
            do
            {
                valor = 0;
                tecla = Console.ReadKey(true);
                switch (tecla.KeyChar)
                {
                    case '1': valor = 1; break;
                    case '2': valor = 2; break;
                    case '3': valor = 3; break;
                    case '4': valor = 4; break;
                    case '5': valor = 5; break;
                }
            } while (valor == 0);

            return valor;
        }
    }

    public interface Interface1
    {
    }

    public interface MENU
    {
        void ShowMenu();
        void ChooseOption();
    }
}
