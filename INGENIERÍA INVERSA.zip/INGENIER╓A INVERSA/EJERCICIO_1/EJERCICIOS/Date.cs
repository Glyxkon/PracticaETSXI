﻿namespace EJERCICIOS
{
    internal class Date
    {
        //Atributos 
        private int dia;
        private int mes;
        private int anio;
        private int hora;

        //Constructores
        public Date(int dia, int mes, int anio, int hora)
        {
            this.dia = dia;
            this.mes = mes;
            this.anio = anio;
            this.hora = hora;
        }

        //Metodos & setters & getters
        // Métodos getters y setters para los atributos
        public int GetDia()
        {
            return this.dia;
        }

        public void SetDia(int dia)
        {
            this.dia = dia;
        }

        public int GetMes()
        {
            return this.mes;
        }

        public void SetMes(int mes)
        {
            this.mes = mes;
        }

        public int GetAnio()
        {
            return this.anio;
        }

        public void SetAnio(int anio)
        {
            this.anio = anio;
        }

        public int GetHora()
        {
            return this.hora;
        }

        public void SetHora(int hora)
        {
            this.hora = hora;
        }

        //Metodos 
        public static Date GetDateNow()
        {
            DateTime now = DateTime.Now;
            return new Date(now.Day, now.Month, now.Year, now.Hour);
        }

    }
}
