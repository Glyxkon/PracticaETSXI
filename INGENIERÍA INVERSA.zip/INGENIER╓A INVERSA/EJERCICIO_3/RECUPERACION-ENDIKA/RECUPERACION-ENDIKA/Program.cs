﻿using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace RECUPERACION_ENDIKA
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //variables
            int option = 0;
            bool noerror = true;
            Agenda agenda= new Agenda();

            do
            {
                Menu.ShowMenu();
                option = Menu.ReadOption();
                Console.Write("\n");
                switch (option)
                {
                    case 1:if (agenda.GetAgenda().Count >= 0) 
                        {
                            int cont = 0;
                            Contacto contactoNuevo = Funciones.SolicitarDatos(agenda);
                            foreach(var contacto in agenda.GetAgenda())
                            {
                                if (contacto.GetNombre() == contactoNuevo.GetNombre())
                                {
                                    cont++;
                                }
                            }
                            if(cont == 0)
                            {
                                agenda.AñadirContacto(contactoNuevo);
                            }
                            else
                            {
                                Console.WriteLine("Nombre cogido, introduzca otro");
                                Console.WriteLine("Pulse enter");
                                Console.ReadKey();
                            }
                        }
                    ; break;

                    case 2:if (agenda.GetAgenda().Count > 0) 
                        {
                            bool comprobar = Funciones.ObtenerContacto(agenda).GetLugar();
                            if ( comprobar == false)
                            {
                                Console.WriteLine("Ya se encuentra en la memoria");
                            }
                            else
                            {
                                Funciones.ObtenerContacto(agenda).MoverMemoria();
                            }
                        }
                        else
                        {
                            Console.WriteLine("No hay ningun contacto todavía.");
                        }
                        Console.ReadKey();
                        ; break;
                    case 3:
                        if (agenda.GetAgenda().Count > 0)
                        {
                            bool comprobar = Funciones.ObtenerContacto(agenda).GetLugar();

                            if (comprobar == true)
                            {
                                Console.WriteLine("Ya se encuentra en la SIM");
                            }
                            else
                            {
                                Funciones.ObtenerContacto(agenda).MoverSim();
                            }
                        }
                        else
                        {
                            Console.WriteLine("No hay ningun contacto todavía.");
                        };
                        Console.ReadKey();

                        break;

                    case 4:
                        if (agenda.GetAgenda().Count > 0)
                        {
                            Console.WriteLine("Introduce el Grupo a cambiar: ");
                            string grupo = Console.ReadLine();
                            if (Funciones.ObtenerContacto(agenda).ModificarGrupo(grupo) == true)
                            {
                                Console.WriteLine("No hubo cambio porque esta en la SIM");

                            }
                            else
                            {
                                Console.WriteLine("Si hubo cambio");
                            }
                        }
                        else
                        {
                            Console.WriteLine("No hay ningun contacto todavía.");
                        };
                        Console.ReadKey();
                        break;

                    case 5:
                        if (agenda.GetAgenda().Count > 0)
                        {
                            Contacto contacto = Funciones.ObtenerContacto(agenda);
                            string tlf = Funciones.ObtenerTelefono(agenda);
                            if (Funciones.ObtenerContacto(agenda).ModificarTlf(tlf) == true)
                            {
                                Console.WriteLine("No hubo cambio porque esta en la SIM");
                                Console.ReadKey();

                            }
                            else
                            {
                                Console.WriteLine("Si hubo cambio");
                                Console.ReadKey();
                            }
                        }
                        else
                        {
                            Console.WriteLine("No hay ningun contacto todavía.");
                        };
                        Console.ReadKey();
                        break;

                    case 6:
                        if (agenda.GetAgenda().Count > 0)
                        {
                            int cont = Funciones.MostrarSim(agenda);
                            if (cont == 0)
                            {
                                Console.WriteLine("No hay contactos en la Memoria");
                                Console.ReadKey();

                            }
                        }
                        else
                        {
                            Console.WriteLine("No hay ningun contacto todavía. No se puede mostrar nada.");
                            Console.ReadKey();
                        };                       
                        break;

                    case 7:
                        if (agenda.GetAgenda().Count > 0)
                        {
                            int cont = Funciones.MostrarMemoria(agenda);
                            if(cont == 0) 
                            {
                                Console.WriteLine("No hay contactos en la Memoria");
                                Console.ReadKey();

                            }
                        }
                        else
                        {
                            Console.WriteLine("No hay ningun contacto todavía. No se puede mostrar nada");
                            Console.ReadKey();
                        };                     
                       break;

                    case 8: noerror = Funciones.Finalizar(); break;
                }

            } while (noerror);

            //Finalizamos
            Funciones.Bye();


        }
    }
}