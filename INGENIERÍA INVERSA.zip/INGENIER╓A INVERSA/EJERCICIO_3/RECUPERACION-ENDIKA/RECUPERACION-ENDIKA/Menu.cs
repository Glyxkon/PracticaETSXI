﻿namespace RECUPERACION_ENDIKA
{
    internal class Menu
    {
        public static void ShowMenu()
        {
            Console.Clear();
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("-AGENDA DE CONTACTOS                         -");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("-  Elige una de las  siguientes opciones:    -");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("- 1. Añadir nuevo contaco                    -");
            Console.WriteLine("- 2. Mover contacto a Memoria                -");
            Console.WriteLine("- 3. Mover contacto a SIM                    -");
            Console.WriteLine("- 4. Modificar Grupo                         -");
            Console.WriteLine("- 5. Modificar Teléfono                      -");
            Console.WriteLine("- 6. Mostrar Contactos de SIM                -");
            Console.WriteLine("- 7. Mostrar Contactos de Memoria            -");
            Console.WriteLine("- 8. Exit AGENDA                             -");
            Console.WriteLine("----------------------------------------------");
        }

        public static int ReadOption()
        {
            ConsoleKeyInfo tecla;
            int valor;
            do
            {
                valor = 0;
                tecla = Console.ReadKey(true);
                switch (tecla.KeyChar)
                {
                    case '1': valor = 1; break;
                    case '2': valor = 2; break;
                    case '3': valor = 3; break;
                    case '4': valor = 4; break;
                    case '5': valor = 5; break;
                    case '6': valor = 6; break;
                    case '7': valor = 7; break;
                    case '8': valor = 8; break;
                }
            } while (valor == 0);

            return valor;
        }
    }

    public interface MENU
    {
        void ReadOption();
        void ShowMenu();
    }
}
