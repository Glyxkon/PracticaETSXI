﻿namespace EXAMEN
{
    internal class Shop : Funciones
    {
        //ATRIBUTOS
        private List<Juego> RentedGames;
        private List<Juego> AvailableGames;
        private string Manager;
        private string Telephone;

        //CONSTRUCTORES
        public Shop()
        {
            RentedGames = new List<Juego>();
            AvailableGames = new List<Juego>();
        }

        internal Juego Juego
        {
            get => default;
            set
            {
            }
        }

        public Menu Menu
        {
            get => default;
            set
            {
            }
        }

        //GETTERS & SETTERS
        public List<Juego> GetRentedGames() { return RentedGames; }
        public void SetRentedGames(List<Juego> rentedGames) { RentedGames = rentedGames; }
        public List<Juego> GetAvailableGames() { return AvailableGames; }
        public void SetAvailableGames(List<Juego> availableGames) { AvailableGames = availableGames; }
        public string GetManager() { return Manager; }
        public void SetManager(string manager) { Manager = manager; }
        public string GetTelephone() { return Telephone; }
        public void SetTelephone(string telephone) { Telephone = telephone; }

        //METODOS
        //Menu
        public void ShowMenu()
        {
            Console.Clear();
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("-  Elija  una de las  siguientes opciones    -");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("- 1. Alquilar juego.                         -");
            Console.WriteLine("- 2. Devolver juego.                         -");
            Console.WriteLine("- 3. Mostrar info tienda.                    -");
            Console.WriteLine("- 4. Mostrar historial.                      -");
            Console.WriteLine("- 5. Exit                                    -");
            Console.WriteLine("----------------------------------------------");
        }

        public int ReadOption()
        {
            ConsoleKeyInfo tecla;
            int valor;
            do
            {
                valor = 0;
                tecla = Console.ReadKey(true);
                switch (tecla.KeyChar)
                {
                    case '1': valor = 1; break;
                    case '2': valor = 2; break;
                    case '3': valor = 3; break;
                    case '4': valor = 4; break;
                    case '5': valor = 5; break;
                }
            } while (valor == 0);

            return valor;
        }
        //Metodo para precargar los Juegos disponibles
        public void SetGames()
        {
            AvailableGames.Add(new Juego("Zelda", 35.70));
            AvailableGames.Add(new Juego("Mario", 30));
            AvailableGames.Add(new Juego("Sonic", 27.40));
            AvailableGames.Add(new Juego("Alex Kid", 15.20));
            AvailableGames.Add(new Juego("Wonder Boy", 21.90));

        }
        //Metodo para mostrar info de la tienda
        public void ShowShopInfo()
        {
            Console.WriteLine($"Encargado de la tienda: {Manager}");
            Console.WriteLine($"Telefono de Tienda: {Telephone}");
            Console.WriteLine("");
            //Mostramos los juegos disponibles
            ShowAvailableGames();
            Console.WriteLine("");
            //Mostramos los juego alquilados
            ShowRentedGames();
        }
        //Metodo para mostrar los juegos disponibles de la tienda
        public void ShowAvailableGames()
        {
            Console.WriteLine("Juegos disponibles:");
            foreach (Juego juego in AvailableGames)
            {
                Console.WriteLine($"Nombre: {juego.GetName()} - Precio: {juego.GetPrice()}");
            }
            Console.WriteLine("Pulsa enter");
            Console.ReadKey();
        }
        //Metodo para mostrar los juegos alquilados de la tienda
        public void ShowRentedGames()
        {
            Console.WriteLine("Juegos alquilados:");
            foreach (Juego juego in RentedGames)
            {
                Console.WriteLine($"Nombre: {juego.GetName()} - Precio: {juego.GetPrice()}");
            }
        }
        //Metodo para alquilar Juego 
        public void RentGame()
        {
            //Solicitamos el codigo de usuario
            string user = Funciones.AskUserName();

            //Solicitamos la seleccion del usuario
            Juego juegoseleccionado = Funciones.SelectGame(this);

            //Añadimos el juego  & Retiramos el juego
            //de la lista de disponibles
            AddRentedGame(juegoseleccionado, user);
        }

        //Metodo para devolver el Juego
        public void ReturnGame()
        {
            //Solicitamos el codigo de usuario
            string user = Funciones.AskUserName();

            //Comprobamos que exista
            if (Funciones.SearchUserCode(this, user))
            {
                //Obtenemos el juego del usuario & lo devolvemso
                RemoveRentedGame(Funciones.SearchRentedGame(this, user));
            }
            else
            {
                Console.WriteLine($"El codigo {user} de usuario no existe.");
            }
        }

        //Metodos para añadir Juegos a la lista de rented
        public void AddRentedGame(Juego juego, string usu)
        {
            Historial history = new Historial();
            history.SetUserCode(usu);
            history.SetTotal(juego.GetPrice());
            juego.SetHistorial(history);
            juego.SetUser(usu);
            RentedGames.Add(juego);
            AvailableGames.Remove(juego);
            Console.WriteLine("Juego ingresado con exito.");
            Console.WriteLine("Pulse enter");
            Console.ReadKey();
        }

        //Metodo para retirar Juegos de la lista de rented
        public void RemoveRentedGame(Juego juego)
        {
            juego.SetUser(string.Empty);
            RentedGames.Remove(juego);
            AvailableGames.Add(juego);
            Console.WriteLine("Juego retirado con exito.");
            Console.WriteLine("Pulse enter");
            Console.ReadKey();
        }



    }
}
