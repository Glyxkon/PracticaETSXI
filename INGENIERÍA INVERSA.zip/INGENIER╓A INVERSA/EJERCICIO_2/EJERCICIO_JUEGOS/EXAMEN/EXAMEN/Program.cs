﻿namespace EXAMEN
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Antes de inciar la tienda
            string name = Funciones.AskNameToBoss();
            string tlf = Funciones.AskTlfToBoss();

            //Comprbamos que no sean nulos para iniciar la tienda
            if (name != null && tlf != null)
            {
                bool noerror = true;
                Shop shop = new Shop();
                shop.SetGames();

                do
                {
                    //Creamos una instancia de la tienda
                    int option = 0;
                    shop.ShowMenu();
                    option = shop.ReadOption();
                    Console.Write("\n");
                    switch (option)
                    {
                        case 1: shop.RentGame(); break;
                        case 2: shop.ReturnGame(); break;
                        case 3: shop.ShowShopInfo(); break;
                        case 4: Funciones.ShowHistory(shop); break;
                        case 5: noerror = Funciones.Finalizar(); break;
                    }

                } while (noerror);

                //Finalizamos el programa
                Funciones.Bye();
            }
            else
            {
                Console.WriteLine("Ha habido un error al leer los datos de usuario");
                //Finalizamos el programa
                Funciones.Bye();
            }

           
        }
    }

    public interface Menu
    {
        void ShowMenu();
    }
}