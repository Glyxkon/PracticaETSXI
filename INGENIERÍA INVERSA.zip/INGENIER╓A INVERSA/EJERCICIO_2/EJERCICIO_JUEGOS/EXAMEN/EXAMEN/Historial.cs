﻿namespace EXAMEN
{
    internal class Historial
    {

        //ATRIBUTOS
        private List<string> usersCode;
        private double Total;

        //Constructores
        public Historial()
        {
            usersCode = new List<string>();
        }
        public Historial(List<string> usersCode, double total)
        {
            this.usersCode = usersCode;
            this.Total = total;
        }

        //GETTER Y SETTERS
        public List<string> GetUserCode()
        {
            return usersCode;
        }
        public void SetUserCode(string user)
        {
            this.usersCode.Add(user);

        }
        public double GetTotal()
        {
            return Total;
        }
        public void SetTotal(double total)
        {
            this.Total += total;
        }
    }
}
