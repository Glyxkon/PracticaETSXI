﻿namespace EXAMEN
{
    internal class Juego
    {
        //ATRIBUTOS
        private string Name;
        private double Price;
        private string user;
        private Historial History;

        //Constructores
        public Juego() { }

        public Juego(string name, double price)
        {
            this.Name = name;
            this.Price = price;
        }
        public Juego(string nombre, double precio, Historial history, string user)
        {
            this.Name = nombre;
            this.Price = precio;
            this.History = history;
            this.user = user;
        }

        internal Historial Historial
        {
            get => default;
            set
            {
            }
        }

        //GETTER Y SETTERS
        public string GetName()
        {
            return Name;
        }

        public void SetName(string nombre)
        {
            Name = nombre;
        }

        public double GetPrice()
        {
            return Price;
        }

        public void SetPrice(double precio)
        {
            Price = precio;
        }

        public Historial GetHistorial()
        {
            return History;
        }
        public void SetHistorial(Historial historial)
        {
            History = historial;
        }

        public string GetUser()
        {
            return user;
        }
        public void SetUser(string user)
        {
            this.user = user;
        }

    }
}
