﻿namespace EXAMEN
{
    internal class Funciones
    {
        //Funcion para pedir las credenciales 2
        public static string AskTlfToBoss()
        {
            bool validate = false;
            string telephone = "";
            while (!validate)
            {
                Console.Write("Introduzca el telfono de la tienda: ");
                telephone = Console.ReadLine();
                if (telephone.Substring(0,3) != "922" || telephone.Length < 9 || telephone.Length > 10)
                {
                    Console.WriteLine("Telefono invalido. Introduzca otro: ");
                }
                else
                {
                    validate = true;
                }
            }
            return telephone;
        }
        //Funcion para pedir las credenciales 1 
        public static string AskNameToBoss()
        {
            bool validate = false;
            string name = "";
            while (!validate)
            {
                Console.Write("Introduzca su nombre: ");
                name = Console.ReadLine();
                if (name.Length < 3)
                {
                    Console.WriteLine("Usuario demasiado corto. Introduzca otro: ");
                }
                else
                {
                    validate = true;
                }
            }
            return name;
        }

        //Funcion para mostrar el historial de un juego en concreto
        public static void ShowHistory(Shop shop)
        {
            int counter = 1;
            //Solicitamos al usuario que esoja un juego para ver su historial
            Juego juegoUsuario = SelectGame(shop);

            Console.WriteLine($"Titulo: {juegoUsuario.GetName()}");
            Console.WriteLine($"Total: {juegoUsuario.GetHistorial().GetTotal()}");
            Console.WriteLine("");
            Console.WriteLine($"Personas que han alquilado {juegoUsuario.GetName()} :");
            if (juegoUsuario.GetHistorial().GetUserCode().Count > 0)
            {
                foreach (string user in juegoUsuario.GetHistorial().GetUserCode())
                {
                    Console.WriteLine($"{counter}.-{user}");
                    counter++;
                }
            }
            else
            {
                Console.WriteLine($"No hay usuarios que han alquilado{juegoUsuario.GetName()}");
            }
            Console.ReadKey();
        }

        //Funcion para buscar el juego que tiene el usuario
        public static Juego SearchRentedGame(Shop shop, string user)
        {
            Juego juegoUser = new Juego();

            foreach (Juego juego in shop.GetRentedGames())
            {
                if (juego.GetUser() == user)
                {
                    juegoUser = juego;
                }
            }
            return juegoUser;
        }

        //Funcion para buscar si el usuario tiene juegos alquilados 
        public static bool SearchUserCode(Shop shop, string user)
        {
            bool retorno = false;
            foreach (Juego juego in shop.GetRentedGames())
            {
                if (juego.GetUser() == user)
                {
                    retorno = true;
                }

            }
            return retorno;
        }

        //Funcion para solicitar el codigo de usuario
        public static string AskUserName()
        {
            Console.WriteLine("Ingrese su codigo de usuario:");
            string usu = Console.ReadLine();
            return usu;
        }
        //Funcion para Solicitar el Juego
        public static Juego SelectGame(Shop shop)
        {
            int counter = 1;
            Juego Game = new Juego();

            Console.WriteLine("Seleccione un juego : ");
            foreach (Juego juego in shop.GetAvailableGames())
            {
                Console.WriteLine($"{counter}.- {juego.GetName()} - Precio: {juego.GetPrice()}$");
                counter++;
            }

            int opcion;
            while (!int.TryParse(Console.ReadLine(), out opcion) || opcion < 1 || opcion > shop.GetAvailableGames().Count)
            {
                Console.WriteLine($"Por favor, ingrese un número válido entre 1 y {shop.GetAvailableGames().Count}.");
            }

            Game = shop.GetAvailableGames()[opcion - 1];

            return Game;
        }

        //Funcion para finalizar el programa
        public static bool Finalizar()
        {
            return false;
        }

        //Para finalizar el programa 
        public static void Bye()
        {
            Console.WriteLine("Muchas gracias por su visita. Esperemos que vuelva pronto.");
            Console.WriteLine("");
            Console.WriteLine("Pulse enter.");
            Console.ReadKey();
        }
    }

    public interface Interface1
    {
    }
}
